package hei.devweb.projetDevWeb.dao.impl;


import hei.devWeb.projetDevWeb.dao.PalmaresDao;
import hei.devWeb.projetDevWeb.dao.impl.DataSourceProvider;
import hei.devWeb.projetDevWeb.dao.impl.PalmaresDaoImpl;
import hei.devWeb.projetDevWeb.entities.Palmares;
import hei.devWeb.projetDevWeb.entities.Tournoi;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;

public class PalmaresDaoTestCase {
    private PalmaresDao palmaresDao = new PalmaresDaoImpl();

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement stmt = connection.createStatement()) {
            stmt.executeUpdate("DELETE FROM palmares");
            stmt.executeUpdate("DELETE FROM tournoi");
            stmt.executeUpdate("INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (1,'Open Australie')");
            stmt.executeUpdate("INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (2,'Roland-Garros')");
            stmt.executeUpdate(
                    "INSERT INTO `palmares`(`palmares_id`,`annee`, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) "
                            + "VALUES (1, '2017', 1, 'Grand-Chelem', 'Dur Ext.', 'Finaliste', 'Roger Federer', '4-6, 6-3, 1-6, 6-3, 3-6')");
            stmt.executeUpdate(
                    "INSERT INTO `palmares`(`palmares_id`,`annee`, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) "
                    + "VALUES (2, '2017', 2, 'Grand-Chelem', 'Terre Battue', 'Vainqueur', 'Stan Wavrinka', '6-2, 6-3, 6-1')");
        }
    }

    @Test
    public void shouldListPalmares() {
        // WHEN
        List<Palmares> palmares = palmaresDao.listPalmares();
        // THEN
        assertThat(palmares).hasSize(2);
        assertThat(palmares).extracting("idPalmares", "annee", "nomTournoi.idTournoi", "nomTournoi.nomTournoi", "categorieTournoi", "surface", "resultat", "adversaireFinale", "score").containsOnly(
                tuple(1, "2017", 1, "Open Australie", "Grand-Chelem", "Dur Ext.", "Finaliste", "Roger Federer", "4-6, 6-3, 1-6, 6-3, 3-6"),
                tuple(2, "2017", 2, "Roland-Garros", "Grand-Chelem", "Terre Battue", "Vainqueur", "Stan Wavrinka", "6-2, 6-3, 6-1")
        );

    }

    @Test
    public void shouldGetPalmares() {
        // WHEN
        Palmares palmares = palmaresDao.getPalmares(1);
        // THEN
        assertThat(palmares).isNotNull();
        assertThat(palmares.getIdPalmares()).isEqualTo(1);
        assertThat(palmares.getNomTournoi().getIdTournoi()).isEqualTo(1);
        assertThat(palmares.getNomTournoi().getNomTournoi()).isEqualTo("Open Australie");
        assertThat(palmares.getAnnee()).isEqualTo("2017");
        assertThat(palmares.getCategorieTournoi()).isEqualTo("Grand-Chelem");
        assertThat(palmares.getSurface()).isEqualTo("Dur Ext.");
        assertThat(palmares.getResultat()).isEqualTo("Finaliste");
        assertThat(palmares.getAdversaireFinale()).isEqualTo("Roger Federer");
        assertThat(palmares.getScore()).isEqualTo("4-6, 6-3, 1-6, 6-3, 3-6");
    }

    @Test
    public void shouldAddPalmares() throws Exception {
        // GIVEN
        Palmares newPalmares = new Palmares(null, new Tournoi(1, "Open Australie"), "year","mon nouveau resultat","mon nouvel adversaire", "mon nouveau score",
                "ma nouvelle categorie", "ma nouvelle surface");
        // WHEN
        Palmares createdPalmares = palmaresDao.addPalmares(newPalmares);
        // THEN
        assertThat(createdPalmares).isNotNull();
        assertThat(createdPalmares.getIdPalmares()).isNotNull();
        assertThat(createdPalmares.getIdPalmares()).isGreaterThan(0);
        assertThat(createdPalmares.getNomTournoi().getIdTournoi()).isEqualTo(1);
        assertThat(createdPalmares.getNomTournoi().getNomTournoi()).isEqualTo("Open Australie");
        assertThat(createdPalmares.getAnnee()).isEqualTo("year");
        assertThat(createdPalmares.getResultat()).isEqualTo("mon nouveau resultat");
        assertThat(createdPalmares.getAdversaireFinale()).isEqualTo("mon nouvel adversaire");
        assertThat(createdPalmares.getScore()).isEqualTo("mon nouveau score");
        assertThat(createdPalmares.getCategorieTournoi()).isEqualTo("ma nouvelle categorie");
        assertThat(createdPalmares.getSurface()).isEqualTo("ma nouvelle surface");

        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement stmt = connection.createStatement()) {
            try (ResultSet rs = stmt.executeQuery("SELECT * FROM palmares WHERE annee = 'year'")) {
                assertThat(rs.next()).isTrue();
                assertThat(rs.getInt("palmares_id")).isEqualTo(createdPalmares.getIdPalmares());
                assertThat(rs.getString("tournoi_id")).isEqualTo("1");
                assertThat(rs.getString("annee")).isEqualTo("year");
                assertThat(rs.getString("resultat")).isEqualTo("mon nouveau resultat");
                assertThat(rs.getString("adversaireFinale")).isEqualTo("mon nouvel adversaire");
                assertThat(rs.getString("score")).isEqualTo("mon nouveau score");
                assertThat(rs.getString("categorieTournoi")).isEqualTo("ma nouvelle categorie");
                assertThat(rs.getString("surface")).isEqualTo("ma nouvelle surface");
                assertThat(rs.next()).isFalse();
            }
        }
    }
}

