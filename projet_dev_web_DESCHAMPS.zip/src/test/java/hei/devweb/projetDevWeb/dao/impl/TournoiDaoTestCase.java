package hei.devweb.projetDevWeb.dao.impl;

import hei.devWeb.projetDevWeb.dao.TournoiDao;
import hei.devWeb.projetDevWeb.dao.impl.DataSourceProvider;
import hei.devWeb.projetDevWeb.dao.impl.TournoiDaoImpl;
import hei.devWeb.projetDevWeb.entities.Tournoi;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class TournoiDaoTestCase {

    private TournoiDao tournoiDao = new TournoiDaoImpl() {
    };

    @Before
    public void initDb() throws Exception {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement stmt = connection.createStatement()) {
            stmt.executeUpdate("DELETE FROM palmares");
            stmt.executeUpdate("DELETE FROM tournoi");
            stmt.executeUpdate("INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (1,'Open Australie')");
            stmt.executeUpdate("INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (2,'Roland-Garros')");
            stmt.executeUpdate("INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (3,'Wimbledon')");
            stmt.executeUpdate("INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (4,'US Open')");

        }
    }

    @Test
    public void shouldListTournois() {
        // WHEN
        List<Tournoi> tournois = tournoiDao.listTournois();
        // THEN
        assertThat(tournois).hasSize(4);
        assertThat(tournois).extracting("idTournoi", "nomTournoi").containsOnly(tuple(4,"US Open"), tuple(3, "Wimbledon"), tuple(2, "Roland-Garros"),
                tuple(1, "Open Australie"));
    }

    @Test
    public void shouldGetTournoi() {
        // WHEN
        Tournoi tournoi = tournoiDao.getTournoi(1);
        // THEN
        assertThat(tournoi).isNotNull();
        assertThat(tournoi.getIdTournoi()).isEqualTo(1);
        assertThat(tournoi.getNomTournoi()).isEqualTo("Open Australie");
    }

    @Test
    public void shouldNotGetUnknownTournoi() {
        // WHEN
        Tournoi tournoi = tournoiDao.getTournoi(-1);
        // THEN
        assertThat(tournoi).isNull();
    }

    @Test
    public void shouldAddTournoi() throws Exception {
        // WHEN
        tournoiDao.addTournoi("test");
        // THEN
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement stmt = connection.createStatement()) {
            try (ResultSet rs = stmt.executeQuery("SELECT * FROM tournoi WHERE nomTournoi = 'test'")) {
                assertThat(rs.next()).isTrue();
                assertThat(rs.getInt("tournoi_id")).isGreaterThan(0);
                assertThat(rs.getString("nomTournoi")).isEqualTo("test");
                assertThat(rs.next()).isFalse();
            }
        }
    }

    @Test
    public void shoudModifyTournoi() throws Exception {
        // WHEN
        tournoiDao.modifyTournoi( "test");
        // THEN
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             Statement stmt = connection.createStatement()) {
            try (ResultSet rs = stmt.executeQuery("SELECT * FROM tournoi WHERE nomTournoi = 'test'")) {
                assertThat(rs.next()).isTrue();
                assertThat(rs.getInt("tournoi_id")).isGreaterThan(0);
                assertThat(rs.getString("nomTournoi")).isEqualTo("test");
                assertThat(rs.next()).isFalse();
            }
        }
    }
}
