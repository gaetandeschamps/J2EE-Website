DELETE FROM tournoi;
DELETE FROM palmares;

INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (1,'Open Australie');
INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (2,'Roland-Garros');
INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (3,'Wimbledon');
INSERT INTO `tournoi`(`tournoi_id`,`nomTournoi`) VALUES (4,'US Open');

INSERT INTO `palmares`(`palmares_id`, `annee`, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) VALUES (1, '2017', 1, 'Grand-Chelem', 'Dur Ext.', 'Finale', 'Roger Federer', '4-6, 6-3, 1-6, 6-3, 3-6');
INSERT INTO `palmares`(`palmares_id`, `annee`, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) VALUES (2, '2017', 2, 'Grand-Chelem', 'Terre-Battue', 'Vainqueur', 'Stan Wavrinka', '6-2, 6-3, 6-1');
INSERT INTO `palmares`(`palmares_id`, `annee`, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) VALUES (3, '2010', 3, 'Grand-Chelem', 'Gazon', 'Vainqueur', 'Tomas Berdych', '6-3, 7-5, 6-4');
INSERT INTO `palmares`(`palmares_id`, `annee`, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) VALUES (4, '2017', 4, 'Grand-Chelem', 'Dur Ext.', 'Vainqueur', 'Kevin Anderson', '6-3, 6-3, 6-4');

