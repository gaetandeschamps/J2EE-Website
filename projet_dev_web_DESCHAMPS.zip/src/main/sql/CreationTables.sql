CREATE TABLE `palmares` (
  `palmares_id` int(11) NOT NULL AUTO_INCREMENT,
  `annee` varchar(5) NOT NULL,
  `tournoi_id` int(11) NOT NULL,
  `categorieTournoi` varchar(45) NOT NULL,
  `surface` varchar(45) NOT NULL,
  `resultat` varchar(45) NOT NULL,
  `adversaireFinale` varchar(45) NOT NULL,
  `score` varchar(45) NOT NULL,
  PRIMARY KEY (`palmares_id`),
  KEY `tournoi_id_fk` (`tournoi_id`),
  CONSTRAINT `tournoi_id_fk` FOREIGN KEY (`tournoi_id`) REFERENCES `tournoi` (`tournoi_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE `tournoi` (
  `tournoi_id` int(11) NOT NULL AUTO_INCREMENT,
  `nomTournoi` varchar(30) NOT NULL,
  PRIMARY KEY (`tournoi_id`)
);