package hei.devWeb.projetDevWeb.managers;

import hei.devWeb.projetDevWeb.dao.PalmaresDao;
import hei.devWeb.projetDevWeb.dao.TournoiDao;
import hei.devWeb.projetDevWeb.dao.impl.PalmaresDaoImpl;
import hei.devWeb.projetDevWeb.dao.impl.TournoiDaoImpl;
import hei.devWeb.projetDevWeb.entities.Palmares;
import hei.devWeb.projetDevWeb.entities.Tournoi;

import java.util.*;

import java.util.ArrayList;
import java.util.List;
public class 	ListeTournoi {

    private static class ListeTournoiHolder {
        private final static ListeTournoi instance = new ListeTournoi();
    }

    public static ListeTournoi getInstance() {
        return ListeTournoiHolder.instance;
    }

    private TournoiDao tournoiDao = new TournoiDaoImpl();
    private PalmaresDao palmaresDao = new PalmaresDaoImpl();

    private ListeTournoi() {
    }

    public List<Palmares> listPalmares() {
        return palmaresDao.listPalmares();
    }

    public Palmares getPalmares(Integer idPalmares) { return palmaresDao.getPalmares(idPalmares);
    }

    public Palmares addPalmares(Palmares palmares) {
        if (palmares == null) {
            throw new IllegalArgumentException("Le palmarès ne doit pas être nul.");
        }
        if (palmares.getNomTournoi() == null) {
            throw new IllegalArgumentException("Le nom du tournoi ne doit pas être vide !");
        }
        if (palmares.getCategorieTournoi() == null || "".equals(palmares.getCategorieTournoi())) {
            throw new IllegalArgumentException("La catégorie du tournoi ne doit pas être nulle !");
        }
        if (palmares.getAdversaireFinale()== null || "".equals(palmares.getAdversaireFinale())) {
            throw new IllegalArgumentException("Le nom de l'adversaire ne doit pas être nul.");
        }
        if (palmares.getResultat() == null || "".equals(palmares.getResultat())) {
            throw new IllegalArgumentException("Le résultat ne doit pas être nul.");
        }
        if (palmares.getAnnee() == null || "".equals(palmares.getAnnee())) {
            throw new IllegalArgumentException("L'année ne doit pas être nulle.");
        }
        if (palmares.getScore() == null || "".equals(palmares.getScore())) {
            throw new IllegalArgumentException("Le score ne doit pas être nul.");
        }
        if (palmares.getSurface() == null || "".equals(palmares.getSurface())) {
            throw new IllegalArgumentException("Le type de surface ne doit pas être nul.");
        }

        return palmaresDao.addPalmares(palmares);
    }

    public void deletePalmares(Integer idPalmares){
        if(idPalmares == null){
            throw new IllegalArgumentException("Il n'y aucun tournoi !");
        }
        palmaresDao.deletePalmares(idPalmares);}

    public List<Tournoi> listTournois() {
        return tournoiDao.listTournois();
    }

    public Tournoi getTournoi(Integer idTournoi) {
        return tournoiDao.getTournoi(idTournoi);
    }

    public void addTournoi(String nomTournoi) {
        if (nomTournoi == null || "".equals(nomTournoi)) {
            throw new IllegalArgumentException("Le nom du tournoi ne doit pas être vide.");
        }
        tournoiDao.addTournoi(nomTournoi);
    }

    public void deleteTournoi(Integer idTournoi){
        if(idTournoi == null){
            throw new IllegalArgumentException("Il n'y aucun tournoi !");
        }
        tournoiDao.deleteTournoi(idTournoi);}

    public void modifyTournoi(String nomTournoi) {
        if (nomTournoi == null || "".equals(nomTournoi)) {
            throw new IllegalArgumentException("Le nom du tournoi ne doit pas être vide.");
        }
        tournoiDao.modifyTournoi(nomTournoi);
    }
    public Integer compterNombreTournoi() {
        return tournoiDao.listTournois().size();
    }

}
