package hei.devWeb.projetDevWeb.entities;

import java.time.Year;

public class Palmares {

    private Integer idPalmares;
    private Tournoi nomTournoi;
    private String annee;
    private String resultat;
    private String adversaireFinale;
    private String score;
    private String categorieTournoi;
    private String surface;

    public Palmares(Integer idPalmares, Tournoi nomTournoi, String annee, String resultat, String adversaireFinale, String score, String categorieTournoi, String surface){
        super();
        this.idPalmares = idPalmares;
        this.nomTournoi = nomTournoi;
        this.annee = annee;
        this.resultat = resultat;
        this.adversaireFinale = adversaireFinale;
        this.score = score;
        this.categorieTournoi = categorieTournoi;
        this.surface = surface;
    }

    public String getResultat() {
        return resultat;
    }

    public void setResultat(String resultat) {
        this.resultat = resultat;
    }

    public String getAdversaireFinale() {
        return adversaireFinale;
    }

    public void setAdversaireFinale(String adversaireFinale) {
        this.adversaireFinale = adversaireFinale;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public Integer getIdPalmares() {
        return idPalmares;
    }

    public void setIdPalmares(Integer idPalmares) {
        this.idPalmares = idPalmares;
    }

    public String getAnnee() {
        return annee;
    }

    public void setAnnee(String annee) {
        this.annee = annee;
    }

    public Tournoi getNomTournoi() {
        return nomTournoi;
    }

    public void setNomTournoi(Tournoi nomTournoi) {
        this.nomTournoi = nomTournoi;
    }

    public String getCategorieTournoi() {
        return categorieTournoi;
    }

    public void setCategorieTournoi(String categorieTournoi) {
        this.categorieTournoi = categorieTournoi;
    }

    public String getSurface() {
        return surface;
    }

    public void setSurface(String surface) {
        this.surface = surface;
    }
}
