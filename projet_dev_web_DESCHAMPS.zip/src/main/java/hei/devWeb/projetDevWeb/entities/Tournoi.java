package hei.devWeb.projetDevWeb.entities;


public class Tournoi {

    private Integer idTournoi;
    private String nomTournoi;


    public Tournoi(Integer idTournoi, String nomTournoi) {
        super();
        this.idTournoi = idTournoi;
        this.nomTournoi = nomTournoi;

    }

    public Integer getIdTournoi() {
        return idTournoi;
    }

    public void setIdTournoi(Integer idTournoi) {
        this.idTournoi = idTournoi;
    }

    public String getNomTournoi() {
        return nomTournoi;
    }

    public void setNomTournoi(String nomTournoi) {
        this.nomTournoi = nomTournoi;
    }

}
