package hei.devWeb.projetDevWeb.dao.impl;

import hei.devWeb.projetDevWeb.dao.TournoiDao;
import hei.devWeb.projetDevWeb.entities.Tournoi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TournoiDaoImpl implements TournoiDao {
    @Override
    public List<Tournoi> listTournois() {
        String query = "SELECT * FROM tournoi ORDER BY nomTournoi;";
        List<Tournoi> listOfTournoi = new ArrayList<>();
        try (
                Connection connection = DataSourceProvider.getDataSource().getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query)
        ) {
            while (resultSet.next()) {
                listOfTournoi.add(new Tournoi(
                        resultSet.getInt("tournoi_id"),
                        resultSet.getString("nomTournoi")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listOfTournoi;
    }

    @Override
    public Tournoi getTournoi(Integer id) {
        String query = "SELECT * FROM tournoi WHERE tournoi_id=?";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Tournoi(resultSet.getInt("tournoi_id"), resultSet.getString("nomTournoi"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void addTournoi(String nom) {
        String query = "INSERT INTO tournoi(nomTournoi) VALUES(?)";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, nom);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void deleteTournoi(Integer idTournoi) {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM tournoi WHERE tournoi_id=?")) {
                statement.setInt(1, idTournoi);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            // Manage Exception
            e.printStackTrace();
        }
    }

    @Override
    public void modifyTournoi(String nom) {
        String query = "INSERT INTO tournoi(nomTournoi) VALUES (?)";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, nom);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
