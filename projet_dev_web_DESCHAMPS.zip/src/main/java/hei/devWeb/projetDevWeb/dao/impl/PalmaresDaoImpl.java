package hei.devWeb.projetDevWeb.dao.impl;

import hei.devWeb.projetDevWeb.dao.PalmaresDao;
import hei.devWeb.projetDevWeb.entities.Palmares;
import hei.devWeb.projetDevWeb.entities.Tournoi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PalmaresDaoImpl implements PalmaresDao {
    @Override
    public List<Palmares> listPalmares() {
        String query = "SELECT * FROM palmares JOIN tournoi ON palmares.tournoi_id = tournoi.tournoi_id";
        List<Palmares> listOfPalmares = new ArrayList<>();
        try (
                Connection connection = DataSourceProvider.getDataSource().getConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query)
        ) {
            while (resultSet.next()) {
                listOfPalmares.add(
                        new Palmares(
                            resultSet.getInt("palmares_id"),
                            new Tournoi(resultSet.getInt("tournoi_id"), resultSet.getString("nomTournoi")),
                            resultSet.getString("annee"),
                            resultSet.getString("resultat"),
                            resultSet.getString("adversaireFinale"),
                            resultSet.getString("score"),
                            resultSet.getString("categorieTournoi"),
                            resultSet.getString("surface"))
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listOfPalmares;
    }

    @Override
    public Palmares getPalmares(Integer id) {
        String query = "SELECT * FROM palmares JOIN tournoi ON palmares.tournoi_id = tournoi.tournoi_id WHERE palmares_id=?";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Palmares(
                            resultSet.getInt("palmares_id"),
                            new Tournoi(resultSet.getInt("tournoi_id"), resultSet.getString("nomTournoi")),
                            resultSet.getString("annee"),
                            resultSet.getString("resultat"),
                            resultSet.getString("adversaireFinale"),
                            resultSet.getString("score"),
                        resultSet.getString("categorieTournoi"),
                            resultSet.getString("surface"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Palmares addPalmares(Palmares palmares) {
        String query = "INSERT INTO palmares(annee, tournoi_id, categorieTournoi, surface, resultat, adversaireFinale, score) VALUES(?, ?, ?, ?, ?, ?,?)";
        try (Connection connection = DataSourceProvider.getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, palmares.getAnnee());
            statement.setInt(2, palmares.getNomTournoi().getIdTournoi());
            statement.setString(3, palmares.getCategorieTournoi());
            statement.setString(4, palmares.getSurface());
            statement.setString(5, palmares.getResultat());
            statement.setString(6, palmares.getAdversaireFinale());
            statement.setString(7, palmares.getScore());
            statement.executeUpdate();

            try (ResultSet ids = statement.getGeneratedKeys()) {
                if(ids.next()) {
                    int generatedId = ids.getInt(1);
                    palmares.setIdPalmares(generatedId);
                    return palmares;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void deletePalmares(Integer idPalmares) {
        try (Connection connection = DataSourceProvider.getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM palmares WHERE palmares_id=?")) {
                statement.setInt(1, idPalmares);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            // Manage Exception
            e.printStackTrace();
        }
    }
}