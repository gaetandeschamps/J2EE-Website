package hei.devWeb.projetDevWeb.dao;

import hei.devWeb.projetDevWeb.entities.Tournoi;

import java.util.List;

public interface TournoiDao {

    public List<Tournoi> listTournois();

    public Tournoi getTournoi(Integer id);

    public void addTournoi(String nom);

    public void deleteTournoi(Integer tournoiId);

    public void modifyTournoi(String nom);
}
