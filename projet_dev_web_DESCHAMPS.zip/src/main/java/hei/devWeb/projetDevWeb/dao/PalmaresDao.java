package hei.devWeb.projetDevWeb.dao;


import hei.devWeb.projetDevWeb.entities.Palmares;

import java.util.List;

public interface PalmaresDao {

    public List<Palmares> listPalmares();

    public Palmares getPalmares(Integer id);

    public Palmares addPalmares(Palmares palmares);

    public void deletePalmares(Integer idPalmares);


}
