package hei.devWeb.projetDevWeb.servlet;

import hei.devWeb.projetDevWeb.entities.Tournoi;
import hei.devWeb.projetDevWeb.managers.ListeTournoi;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/ajouterTournoi")
public class AjouterTournoi extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(req.getServletContext());
        templateResolver.setPrefix("/WEB-INF/templates/");
        templateResolver.setSuffix(".html");

        WebContext context = new WebContext(req,resp,req.getServletContext());

        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        templateEngine.process("ajouterTournoi", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //on récupère le(s) paramètre(s) mis dans le from
        String nomTournoi = req.getParameter("nomTournoi");

        //création d'un nouveau tournoi
        try {
            ListeTournoi.getInstance().addTournoi(nomTournoi);
        } catch (IllegalArgumentException e) {
            resp.sendRedirect("error");
            return;
        }
        //redirection page préc.
        resp.sendRedirect("tournoi");
    }
}
