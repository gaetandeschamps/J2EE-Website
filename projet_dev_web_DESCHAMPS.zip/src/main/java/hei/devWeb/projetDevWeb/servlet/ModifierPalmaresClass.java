package hei.devWeb.projetDevWeb.servlet;

import hei.devWeb.projetDevWeb.entities.Palmares;
import hei.devWeb.projetDevWeb.entities.Tournoi;
import hei.devWeb.projetDevWeb.managers.ListeTournoi;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.format.DateTimeParseException;
import java.util.List;

@WebServlet("/modifierPalmares")
public class ModifierPalmaresClass extends HttpServlet {

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(req.getServletContext());
            templateResolver.setPrefix("/WEB-INF/templates/");
            templateResolver.setSuffix(".html");

            WebContext context = new WebContext(req, resp, req.getServletContext());
            List<Palmares> palmares = ListeTournoi.getInstance().listPalmares();
            context.setVariable("palmaresList", palmares);

            TemplateEngine templateEngine = new TemplateEngine();
            templateEngine.setTemplateResolver(templateResolver);

            templateEngine.process("modifierPalmares", context, resp.getWriter());
        }

        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            ListeTournoi recetteLibrary = ListeTournoi.getInstance();
            String id = req.getParameter("idPalmares");
            Integer idPalmares = Integer.parseInt(id);

            // GET PARAMETERS
            String annee = null;
            Tournoi nomTournoi = null;
            String categorieTournoi = null;
            String surface = null;
            String resultat = null;
            String adversaireFinale = null;
            String score = null;

            try {
                annee = req.getParameter("annee");
                nomTournoi = ListeTournoi.getInstance().getTournoi(Integer.parseInt(req.getParameter("nomTournoi")));
                categorieTournoi = req.getParameter("categorieTournoi");
                surface = req.getParameter("surface");
                resultat = req.getParameter("resultat");
                adversaireFinale = req.getParameter("adversaireFinale");
                score = req.getParameter("score");

            } catch (NumberFormatException | DateTimeParseException ignored) {

            }
            // CREATE PALMARES
            Palmares newPalmares = new Palmares(null, nomTournoi, annee, resultat,adversaireFinale, score, categorieTournoi, surface);
            try {
                Palmares createdFilm = ListeTournoi.getInstance().addPalmares(newPalmares);
                recetteLibrary.deletePalmares(idPalmares);

                // REDIRECT TO DETAIL PALMARES
                resp.sendRedirect(String.format("palmaresDetails?idPalmares=%d", createdFilm.getIdPalmares()));
            } catch (IllegalArgumentException e) {
                String errorMessage = e.getMessage();

                req.getSession().setAttribute("errorMessage", errorMessage);

                resp.sendRedirect("ajouterPalmares");
            }
        }
}

