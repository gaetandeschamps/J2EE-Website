package hei.devWeb.projetDevWeb.servlet;

import hei.devWeb.projetDevWeb.entities.Tournoi;
import hei.devWeb.projetDevWeb.managers.ListeTournoi;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/modifierTournoi")
public class ModifierTournoiServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(req.getServletContext());
        templateResolver.setPrefix("/WEB-INF/templates/");
        templateResolver.setSuffix(".html");

        WebContext context = new WebContext(req, resp, req.getServletContext());
        List<Tournoi> tournois = ListeTournoi.getInstance().listTournois();
        context.setVariable("tournoiList", tournois);

        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        templateEngine.process("modifierTournoi", context, resp.getWriter());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ListeTournoi recetteLibrary = ListeTournoi.getInstance();
        String id = req.getParameter("idTournoi");
        Integer idTournoi = Integer.parseInt(id);

        // GET PARAMETERS
        String nomTournoi = null;

        try {

            nomTournoi = req.getParameter("newNomTournoi");

        } catch (IllegalArgumentException e) {
            String errorMessage = e.getMessage();
            System.out.println("erreur 1:" + errorMessage);
        }
        // CREATE Tournoi
        Tournoi newTournoi = new Tournoi(null, nomTournoi);
        try {
            ListeTournoi.getInstance().addTournoi(nomTournoi);
            recetteLibrary.deleteTournoi(idTournoi);
            resp.sendRedirect(String.format("choisirLesIngredientsFruitLegumes?id=%d", newTournoi.getIdTournoi()));
        } catch (IllegalArgumentException e) {
            String errorMessage = e.getMessage();

            req.getSession().setAttribute("errorMessage", errorMessage);
            System.out.println("erreur 2:" + errorMessage);

            resp.sendRedirect(String.format("modifier?id=%d", Integer.parseInt(id)));
        }
    }
}