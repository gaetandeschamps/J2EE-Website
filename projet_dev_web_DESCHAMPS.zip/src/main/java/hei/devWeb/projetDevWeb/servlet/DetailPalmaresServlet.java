package hei.devWeb.projetDevWeb.servlet;

import hei.devWeb.projetDevWeb.entities.Palmares;
import hei.devWeb.projetDevWeb.managers.ListeTournoi;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/palmaresDetails")
public class DetailPalmaresServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        WebContext context = new WebContext(req, resp, req.getServletContext());
        ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(req.getServletContext());
        templateResolver.setPrefix("/WEB-INF/templates/");
        templateResolver.setSuffix(".html");

        String palmaresId = req.getParameter("idPalmares");
        Palmares palmares = ListeTournoi.getInstance().getPalmares(Integer.parseInt(palmaresId));
        context.setVariable("palmaresList", palmares);

        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);

        templateEngine.process("palmaresDetail", context, resp.getWriter());
    }
}

