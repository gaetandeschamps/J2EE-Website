package hei.devWeb.projetDevWeb.servlet;

import hei.devWeb.projetDevWeb.managers.ListeTournoi;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/supprimerPalmares")
public class SupprimerPalmaresServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String palmaresId=req.getParameter("idPalmares");
        ListeTournoi.getInstance().deletePalmares(Integer.parseInt(palmaresId));
        resp.sendRedirect("palmaresList");
    }
}
