function desactiverTool() {
    var tools = document.querySelectorAll('.tool'),
        toolsLength = tools.length;
    for (var i = 0; i < toolsLength; i++) {
        tools[i].style.display = 'none';
    }
}

function gettool(elements) {
    while (elements = elements.nextSibling) {
        if (elements.className === 'tool') {
            return elements;
        }
    }
    return false;
}

var check = {};
check['nomTournoi'] = function() {
    var nomTournoi = document.getElementsByName('nomTournoi'),
        toolStyle = gettool(nomTournoi[1].parentNode).style;
    if (nomTournoi[0].checked || nomTournoi[1].checked) {
        toolStyle.display = 'none';
        return true;
    } else {
        toolStyle.display = 'inline-block';
        return false;
    }

};

(function() {
    var monFormulaire = document.getElementById('monFormulaire'),
        inputs = document.querySelectorAll('input[type=text]'),
        inputsLength = inputs.length;
    for (var i = 0; i < inputsLength; i++) {
        inputs[i].addEventListener('keyup', function(e) {
            check[e.target.id](e.target.id); 
        });
    }

    monFormulaire.addEventListener('submit', function(e) {
        var result = true;
        for (var i in check) {
            result = check[i](i) && result;
        }
        if (result) {
            alert('Element bien ajouté !');
        }
        e.preventDefault();
    });
})();

desactiverTool();