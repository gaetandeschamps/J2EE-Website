function desactiverTool() {
    var tool = document.querySelectorAll('.tool'),
        toolLength = tool.length;
    for (var i = 0; i < toolLength; i++) {
        tool[i].style.display = 'none';
    }

}
function gettool(elements) {
    while (elements = elements.nextSibling) {
        if (elements.className === 'tool') {
            return elements;
        }
    }
    return false;
}

var check = {};
check['resultat'] = function(id) {

    var name = document.getElementById(id),
        toolStyle = getTooltip(name).style;

    if (name.value.length >= 2) {
        name.className = 'vrai';
        toolStyle.display = 'none';
        return true;
    } else {
        name.className = 'faux';
        toolStyle.display = 'inline-block';
        return false;
    }
}
check['adversaireFinale'] = function(id) {

    var name = document.getElementById(id),
        toolStyle = getTooltip(name).style;

    if (name.value.length >= 2) {
        name.className = 'vrai';
        toolStyle.display = 'none';
        return true;
    } else {
        name.className = 'faux';
        toolStyle.display = 'inline-block';
        return false;
    }
}
check['score'] = function(id) {

    var name = document.getElementById(id),
        toolStyle = getTooltip(name).style;

    if (name.value.length >= 2) {
        name.className = 'vrai';
        toolStyle.display = 'none';
        return true;
    } else {
        name.className = 'faux';
        toolStyle.display = 'inline-block';
        return false;
    }

}

desactiverTool();