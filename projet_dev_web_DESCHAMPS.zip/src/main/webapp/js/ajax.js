function compterNombreTournoi() {
    var maRequeteAJAX = new XMLHttpRequest();
    maRequeteAJAX.open("GET", "http://localhost:8080/compterTournoi", true);
    maRequeteAJAX.responseType = "text";
    maRequeteAJAX.onload = function () {
        var res = this.response;
        console.log("Nombre de tournoi : " + res);
        document.getElementById("nombreTournois").innerHTML = res;
    };
}
